import { NextResponse } from "next/server";
import { sql } from "../../../lib/db";

export async function GET() {
  try {
    const result = await sql`SELECT 1 AS test`;

    return NextResponse.json({
      ok: true,
      result,
    });
  } catch (error) {
    console.error("TEST-DB ERROR:", error);

    return NextResponse.json(
      {
        ok: false,
        error: error instanceof Error ? error.message : String(error),
      },
      { status: 500 }
    );
  }
}