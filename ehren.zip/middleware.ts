import { clerkMiddleware, createRouteMatcher } from "@clerk/nextjs/server";

const isBackendApiRoute = createRouteMatcher([
  "/api/backend(.*)",
]);

export default clerkMiddleware(
  async (auth, request) => {
    if (isBackendApiRoute(request)) {
      await auth.protect();
    }
  },
  {
    debug: true,
  }
);

export const config = {
  matcher: [
    "/((?!_next|[^?]*\\.(?:html?|css|js(?!on)|jpe?g|webp|png|gif|svg|ttf|woff2?|ico|csv|docx?|xlsx?|zip|webmanifest)).*)",
    "/(api|trpc)(.*)",
    "/__clerk/(.*)",
  ],
};