import {NextResponse} from "next/server";
import {auth,clerkClient} from "@clerk/nextjs/server";
import {sql} from "../../../../../lib/db";
const r2=(n:number)=>Math.round(n*100)/100;
export async function POST(r:Request){
 try{
  const {userId}=await auth(); if(!userId)return NextResponse.json({error:"Nicht autorisiert"},{status:401});
  const c=await clerkClient(),u=await c.users.getUser(userId),b=await r.json();
  const pid=+b.product_id,q=+b.quantity,src=+b.source_location_id,dst=+b.destination_id,cc=b.cost_center_id?+b.cost_center_id:null,date=String(b.date||""),note=String(b.note||"").trim()||null,kind=['OUT','SALE','LOSS'].includes(b.kind)?b.kind:'OUT';
  const shippingNet=Number(b.shipping_net||0),shippingTax=Number(b.shipping_tax_rate??19);
  if(!pid||!q||q<=0||!src||!dst||!date)return NextResponse.json({error:"Pflichtfelder prüfen."},{status:400});
  if(!Number.isFinite(shippingNet)||shippingNet<0||!Number.isFinite(shippingTax)||shippingTax<0)return NextResponse.json({error:"Lieferkosten prüfen."},{status:400});
  const[st]=await sql`SELECT COALESCE(quantity,0)::float8 q FROM current_stock WHERE product_id=${pid} AND location_id=${src}`; if(!st||st.q<q)return NextResponse.json({error:"Nicht genügend Bestand."},{status:409});
  const[p]=await sql`SELECT id,name,unit,COALESCE(selling_price,0)::float8 selling_price,COALESCE(tax_rate,19)::float8 tax_rate FROM products WHERE id=${pid} AND active=true`;
  const[a]=await sql`SELECT id,name,billing_street,billing_postal_code,billing_city,billing_country FROM address_book WHERE id=${dst}`; const[s]=await sql`SELECT * FROM invoice_settings WHERE id=1`; if(!p||!a)return NextResponse.json({error:"Produkt oder Empfänger nicht gefunden."},{status:404});
  const netUnit=b.unit_price===""||b.unit_price===undefined?+p.selling_price:+b.unit_price,tax=Number(b.tax_rate??p.tax_rate); if(!Number.isFinite(netUnit)||netUnit<0||!Number.isFinite(tax)||tax<0)return NextResponse.json({error:"Preis oder MwSt. ungültig."},{status:400});
  const name=u.fullName||u.firstName||"User";
  const[m]=await sql`INSERT INTO warehouse_movements(movement_date,movement_type,product_id,quantity,source_location_id,destination_address_id,cost_center_id,note,created_by_clerk_user_id,created_by_name) VALUES(${date},${kind},${pid},${q},${src},${dst},${cc},${note},${userId},${name}) RETURNING id`;
  const productNet=r2(q*netUnit),productVat=r2(productNet*tax/100),shippingVat=r2(shippingNet*shippingTax/100),net=r2(productNet+shippingNet),vat=r2(productVat+shippingVat),gross=r2(net+vat),nr=`RE-${new Date(date).getFullYear()}-${String(m.id).padStart(5,"0")}`,type=kind==='LOSS'?'INTERNAL':gross>0?'INVOICE':'ZERO_RECEIPT',status=kind==='LOSS'||gross===0?'SETTLED':'OPEN';
  const[d]=await sql`INSERT INTO commercial_documents(document_number,document_type,direction,status,document_date,service_date,address_book_id,warehouse_movement_id,cost_center_id,net_amount,tax_amount,gross_amount,note,recipient_name,recipient_street,recipient_postal_code,recipient_city,recipient_country,issuer_name,issuer_street,issuer_postal_code,issuer_city,issuer_country,issuer_tax_number,issuer_vat_id,issuer_iban,issuer_bic,issuer_bank_name,payment_terms_days,created_by_clerk_user_id,created_by_name) VALUES(${nr},${type},'OUTGOING',${status},${date},${date},${dst},${m.id},${cc},${net},${vat},${gross},${note},${a.name},${a.billing_street},${a.billing_postal_code},${a.billing_city},${a.billing_country},${s?.issuer_name||null},${s?.issuer_street||null},${s?.issuer_postal_code||null},${s?.issuer_city||null},${s?.issuer_country||null},${s?.tax_number||null},${s?.vat_id||null},${s?.iban||null},${s?.bic||null},${s?.bank_name||null},${s?.payment_terms_days||14},${userId},${name}) RETURNING id`;
  await sql`INSERT INTO commercial_document_items(document_id,product_id,description,quantity,unit,unit_price,tax_rate,line_total,net_total,tax_total,gross_total) VALUES(${d.id},${pid},${p.name},${q},${p.unit},${netUnit},${tax},${productNet},${productNet},${productVat},${r2(productNet+productVat)})`;
  if(shippingNet>0)await sql`INSERT INTO commercial_document_items(document_id,product_id,description,quantity,unit,unit_price,tax_rate,line_total,net_total,tax_total,gross_total) VALUES(${d.id},${null},'Lieferung',1,'Pauschal',${shippingNet},${shippingTax},${shippingNet},${shippingNet},${shippingVat},${r2(shippingNet+shippingVat)})`;
  return NextResponse.json({ok:true,documentNumber:nr,net,tax:vat,gross});
 }catch(e){console.error(e);return NextResponse.json({error:"Ausbuchung fehlgeschlagen."},{status:500})}
}
